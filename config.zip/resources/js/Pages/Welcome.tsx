import React, { useEffect, useState } from 'react';
import { Head, Link } from '@inertiajs/react';
import { Navbar } from '@/Components/Public/Navbar';
import { Footer } from '@/Components/Public/Footer';
import { Photo } from '@/Components/Public/Photo';
import { FloatingWhatsApp } from '@/Components/Public/FloatingWhatsApp';
import { ScrollProgress } from '@/Components/Public/ScrollProgress';
import { siteConfig, createWhatsAppLink } from '@/data/piaud';

interface WelcomeProps {
    dbLecturers?: Array<{
        id?: number;
        name: string;
        nip: string;
        role: string;
        expertise: string;
        photoUrl: string;
    }>;
    dbArticles?: Array<{
        id: string;
        title: string;
        slug: string;
        category: string;
        publishedAt: string;
        readTime: string;
        excerpt: string;
        photoUrl: string;
        isFeatured?: boolean;
    }>;
    dbGalleries?: Array<{
        title: string;
        photoUrl: string;
        category: string;
        date?: string;
        description?: string;
    }>;
}

export default function Welcome({ dbLecturers, dbArticles, dbGalleries }: WelcomeProps) {
    const waPmbLink = createWhatsAppLink(siteConfig.whatsappDefaultMessage);

    const displayedLecturers = (dbLecturers && dbLecturers.length > 0)
        ? dbLecturers.slice(0, 4)
        : siteConfig.lecturers;

    const displayedGalleries = (dbGalleries && dbGalleries.length > 0)
        ? dbGalleries.slice(0, 4)
        : siteConfig.gallery;

    const featuredArticle = (dbArticles && dbArticles.length > 0)
        ? (dbArticles.find((a) => a.isFeatured) || dbArticles[0])
        : siteConfig.articles.featured;

    const listArticles = (dbArticles && dbArticles.length > 1)
        ? dbArticles.filter((a) => a.id !== featuredArticle.id).slice(0, 3)
        : siteConfig.articles.list;

    // Active in-view state that resets on scroll away and re-animates on scroll into view!
    const [inView, setInView] = useState<Record<string, boolean>>({
        hero: true, // Hero animates immediately on mount
    });

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    const sectionId = entry.target.getAttribute('data-section');
                    if (sectionId) {
                        setInView((prev) => ({
                            ...prev,
                            [sectionId]: entry.isIntersecting,
                        }));
                    }
                });
            },
            { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
        );

        document.querySelectorAll('[data-section]').forEach((el) => observer.observe(el));
        return () => observer.disconnect();
    }, []);

    return (
        <div className="min-h-screen bg-[#FAF6EC] text-piaud-slate flex flex-col font-sans selection:bg-piaud-emerald selection:text-white">
            {/* SEO & Meta Tags */}
            <Head>
                <title>{`${siteConfig.programName} - ${siteConfig.institutionName}`}</title>
                <meta
                    name="description"
                    content={`Program Studi S1 PIAUD IAI Persis Bandung. ${siteConfig.hero.description}`}
                />
                <meta property="og:title" content={`${siteConfig.programName} - ${siteConfig.institutionName}`} />
                <meta property="og:description" content={siteConfig.hero.description} />
                <meta property="og:type" content="website" />
            </Head>

            {/* Sections 1 & 2: Top Bar & Navigation */}
            <Navbar />

            <main className="flex-1 w-full">
                {/* 3. HERO SECTION (Warm Ivory & Structured Proportional Layout) */}
                <section data-section="hero" className="bg-[#FAF6EC] border-b border-[#E3DAC7]">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 md:py-18 lg:py-20">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-10 lg:gap-14 items-stretch">
                            {/* Left Column (7 cols): Measured Slide-Left Entrance */}
                            <div className="lg:col-span-7 flex flex-col justify-between h-full space-y-6">
                                <div className="space-y-5 sm:space-y-6">
                                    <h1
                                        className={`font-serif font-bold text-3xl sm:text-4xl lg:text-5xl text-piaud-slate tracking-tight leading-tight ${
                                            inView.hero ? 'animate-slide-left' : ''
                                        }`}
                                    >
                                        {siteConfig.hero.heading}
                                    </h1>

                                    <p
                                        className={`text-sm sm:text-base md:text-lg text-piaud-slate-muted leading-relaxed max-w-[65ch] ${
                                            inView.hero ? 'animate-slide-left delay-1' : ''
                                        }`}
                                    >
                                        {siteConfig.hero.description}
                                    </p>

                                    {/* Two CTAs with Animated Mount & Tactile Hover Physics */}
                                    <div
                                        className={`pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 ${
                                            inView.hero ? 'animate-slide-up delay-2' : ''
                                        }`}
                                    >
                                        <a
                                            href={waPmbLink}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="group inline-flex items-center justify-center gap-2.5 neu-btn-primary text-white text-xs sm:text-sm font-bold px-7 py-3.5 rounded-xl cursor-pointer"
                                        >
                                            <span>{siteConfig.hero.ctaPrimaryText}</span>
                                            <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">→</span>
                                        </a>
                                        <Link
                                            href="/akademik"
                                            className="group inline-flex items-center justify-center gap-2.5 neu-btn text-piaud-slate text-xs sm:text-sm font-semibold px-6 py-3.5 rounded-xl cursor-pointer"
                                        >
                                            <span>{siteConfig.hero.ctaSecondaryText}</span>
                                            <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">→</span>
                                        </Link>
                                    </div>
                                </div>

                                {/* Stats & Features Cards Row with Decoupled Wrappers for Pure Smooth Hover */}
                                <div className="pt-4 grid grid-cols-3 gap-2.5 sm:gap-4 text-xs">
                                    <div className={inView.hero ? 'animate-slide-up delay-1' : ''}>
                                        <div className="neu-card card-interactive-sm rounded-xl p-3 sm:p-4 flex flex-col justify-center group h-full">
                                            <span className="font-bold text-piaud-slate block text-xs sm:text-sm group-hover:text-[#0F4C3A] transition-colors">Sarjana (S.Pd.)</span>
                                            <span className="text-piaud-slate-muted text-[10px] sm:text-[11px] group-hover:text-[#C2613A] transition-colors">Gelar Lulusan</span>
                                        </div>
                                    </div>
                                    <div className={inView.hero ? 'animate-slide-up delay-2' : ''}>
                                        <div className="neu-card card-interactive-sm rounded-xl p-3 sm:p-4 flex flex-col justify-center group h-full">
                                            <span className="font-bold text-piaud-slate block text-xs sm:text-sm group-hover:text-[#0F4C3A] transition-colors">144 SKS (8 Sem)</span>
                                            <span className="text-piaud-slate-muted text-[10px] sm:text-[11px] group-hover:text-[#C2613A] transition-colors">Masa Studi</span>
                                        </div>
                                    </div>
                                    <div className={inView.hero ? 'animate-slide-up delay-3' : ''}>
                                        <div className="neu-card card-interactive-sm rounded-xl p-3 sm:p-4 flex flex-col justify-center group h-full">
                                            <span className="font-bold text-piaud-slate block text-xs sm:text-sm group-hover:text-[#0F4C3A] transition-colors">Reguler &amp; Guru</span>
                                            <span className="text-piaud-slate-muted text-[10px] sm:text-[11px] group-hover:text-[#C2613A] transition-colors">Kelas Kuliah</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Right Column (5 cols): Photo Card Decoupled Wrapper for Smooth Hover Float */}
                            <div className={`lg:col-span-5 h-full flex flex-col ${inView.hero ? 'animate-slide-right' : ''}`}>
                                <figure className="relative neu-card card-interactive rounded-2xl p-3 sm:p-3.5 h-full flex flex-col justify-center group overflow-hidden">
                                    <div className="w-full h-full min-h-[280px] sm:min-h-[340px] lg:min-h-full overflow-hidden rounded-xl">
                                        <Photo
                                            src={siteConfig.hero.photoUrl}
                                            alt={siteConfig.hero.photoAlt}
                                            priority={true}
                                            aspectRatio="auto"
                                            className="w-full h-full object-cover rounded-xl shadow-soft"
                                        />
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </section>

                {/* 4. SAMBUTAN KAPRODI (Warm Cream Alternating Section) */}
                <section id="profil" data-section="kaprodi" className="bg-[#F2ECE0] border-b border-[#E3DAC7] py-12 sm:py-16 md:py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-10 lg:gap-14 items-center">
                            {/* Kaprodi Photo Card with Smooth Card Hover Lift */}
                            <div className={`lg:col-span-4 space-y-4 ${inView.kaprodi ? 'animate-slide-left' : ''}`}>
                                <figure className="neu-card card-interactive rounded-2xl p-4 group">
                                    <div className="overflow-hidden rounded-xl">
                                        <Photo
                                            src={siteConfig.kaprodi.photoUrl}
                                            alt={`Foto ${siteConfig.kaprodi.name}`}
                                            aspectRatio="3/4"
                                            className="w-full h-auto rounded-xl shadow-soft"
                                        />
                                    </div>
                                    <figcaption className="mt-3.5 space-y-1 px-1">
                                        <p className="font-serif font-bold text-base sm:text-lg text-piaud-slate group-hover:text-[#0F4C3A] transition-colors">
                                            {siteConfig.kaprodi.name}
                                        </p>
                                        <p className="text-xs text-[#C2613A] font-bold">
                                            {siteConfig.kaprodi.title}
                                        </p>
                                        <p className="text-xs text-piaud-slate-muted pt-1 border-t border-[#E3DAC7]">
                                            Fakultas Tarbiyah · IAI Persis Bandung
                                        </p>
                                    </figcaption>
                                </figure>
                            </div>

                            {/* Editorial Content with Measured Slide-Right */}
                            <div className={`lg:col-span-8 space-y-5 ${inView.kaprodi ? 'animate-slide-right delay-1' : ''}`}>
                                <div>
                                    <blockquote className="font-serif text-xl sm:text-2xl text-piaud-slate font-bold leading-relaxed border-l-4 border-[#C2613A] pl-4">
                                        &ldquo;{siteConfig.kaprodi.pullQuote}&rdquo;
                                    </blockquote>
                                </div>

                                <div className="space-y-3.5 text-sm sm:text-base text-piaud-slate-muted leading-relaxed max-w-[65ch]">
                                    {siteConfig.kaprodi.content.map((paragraph, index) => (
                                        <p key={index}>
                                            {paragraph}
                                        </p>
                                    ))}
                                </div>

                                <div className="pt-4 border-t border-[#E3DAC7] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-lg bg-[#0F4C3A] text-white flex items-center justify-center font-serif text-xs font-bold shrink-0 shadow-sm">
                                            PS
                                        </div>
                                        <p className="text-xs text-piaud-slate-muted font-medium">
                                            Komitmen kurikulum berbasis Al-Qur'an, As-Sunnah, dan standar keilmuan PAUD modern.
                                        </p>
                                    </div>
                                    <Link
                                        href="/profil"
                                        className="group inline-flex items-center gap-1.5 text-xs font-bold text-[#0F4C3A] hover:text-[#0A3427] transition-colors shrink-0 tactile-press"
                                    >
                                        <span>Selengkapnya di Profil Prodi</span>
                                        <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">&rarr;</span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* 5. PILAR KEUNGGULAN (Clean Ivory Section with Measured Staggered Scroll Cards) */}
                <section id="kurikulum" data-section="pillars" className="bg-[#FAF6EC] border-b border-[#E3DAC7] py-12 sm:py-16 md:py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className={`text-center max-w-2xl mx-auto mb-10 space-y-2 ${inView.pillars ? 'animate-slide-up' : ''}`}>
                            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-piaud-slate leading-tight">
                                Tiga Pilar Pendidikan Holistik Calon Guru AUD
                            </h2>
                            <p className="text-xs sm:text-sm text-piaud-slate-muted leading-relaxed">
                                Memastikan setiap lulusan memiliki integritas aqidah yang kokoh, kompetensi pedagogik mutakhir, dan keahlian media belajar aplikatif.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {siteConfig.pillars.map((pillar, idx) => (
                                <div
                                    key={pillar.number}
                                    className={`h-full ${inView.pillars ? `animate-slide-up delay-${idx + 1}` : ''}`}
                                >
                                    <div className="neu-card card-interactive rounded-2xl p-6 flex flex-col justify-between group h-full">
                                        <div className="space-y-3.5">
                                            <div className="w-10 h-10 rounded-xl bg-[#0F4C3A] text-white font-serif text-lg font-bold flex items-center justify-center shadow-soft transform group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                                                {pillar.number}
                                            </div>
                                            <h3 className="font-serif text-base sm:text-lg font-bold text-piaud-slate group-hover:text-[#0F4C3A] transition-colors">
                                                {pillar.title}
                                            </h3>
                                            <p className="text-xs sm:text-sm text-piaud-slate-muted leading-relaxed">
                                                {pillar.description}
                                            </p>
                                        </div>

                                        <div className="pt-4 mt-5 border-t border-[#E3DAC7] space-y-2">
                                            <span className="text-xs font-bold text-piaud-slate block">Fokus Capaian:</span>
                                            <ul className="space-y-1.5 text-xs text-piaud-slate-muted">
                                                {pillar.deliverables.map((item, dIdx) => (
                                                    <li key={dIdx} className="flex items-center gap-2 transform group-hover:translate-x-1.5 transition-transform duration-200">
                                                        <span className="w-1.5 h-1.5 bg-[#C2613A] rounded-full shrink-0"></span>
                                                        <span>{item}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className={`mt-8 text-center ${inView.pillars ? 'animate-slide-up delay-4' : ''}`}>
                            <Link
                                href="/akademik"
                                className="group inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#0F4C3A] hover:text-[#0A3427] neu-btn px-6 py-3.5 rounded-xl transition-all cursor-pointer"
                            >
                                <span>Lihat Struktur Kurikulum &amp; Sebaran Mata Kuliah</span>
                                <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">&rarr;</span>
                            </Link>
                        </div>
                    </div>
                </section>

                {/* 6. DOSEN & TENAGA PENGAJAR (Warm Cream Grid with Staggered Scroll Cards) */}
                <section id="dosen" data-section="lecturers" className="bg-[#F2ECE0] border-b border-[#E3DAC7] py-12 sm:py-16 md:py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className={`flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8 pb-3 border-b border-[#E3DAC7] ${inView.lecturers ? 'animate-slide-left' : ''}`}>
                            <div>
                                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-piaud-slate">
                                    Dosen Pengampu &amp; Pakar Tumbuh Kembang
                                </h2>
                            </div>
                            <Link
                                href="/dosen"
                                className="group inline-flex items-center gap-1.5 text-xs font-bold text-[#0F4C3A] hover:text-[#0A3427] transition-colors self-start md:self-auto cursor-pointer"
                            >
                                <span>Lihat Semua Dosen</span>
                                <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">&rarr;</span>
                            </Link>
                        </div>

                        {/* Crisp Responsive Cards Grid with Decoupled Wrappers for Smooth Hover Lift */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            {displayedLecturers.map((lecturer, index) => (
                                <div
                                    key={index}
                                    className={`h-full ${inView.lecturers ? `animate-slide-up delay-${index + 1}` : ''}`}
                                >
                                    <article className="neu-card card-interactive rounded-2xl p-4 group h-full flex flex-col justify-between">
                                        <div>
                                            <div className="overflow-hidden rounded-xl border border-[#E3DAC7]">
                                                <Photo
                                                    src={lecturer.photoUrl}
                                                    alt={`Foto ${lecturer.name}`}
                                                    aspectRatio="1/1"
                                                    className="w-full h-auto rounded-xl shadow-soft"
                                                />
                                            </div>

                                            <div className="mt-3.5 space-y-1.5">
                                                <span className="text-[11px] font-bold tracking-wider text-[#C2613A] uppercase block transform group-hover:translate-x-1.5 transition-transform duration-200">
                                                    {lecturer.role}
                                                </span>
                                                <h3 className="font-serif font-bold text-base text-piaud-slate leading-snug group-hover:text-[#0F4C3A] transition-colors">
                                                    {lecturer.name}
                                                </h3>
                                            </div>
                                        </div>

                                        <div className="pt-2 mt-3 border-t border-[#E3DAC7] text-xs text-piaud-slate-muted space-y-1">
                                            <p className="font-mono text-[11px] text-slate-500">
                                                NIP: {lecturer.nip}
                                            </p>
                                            <p className="text-piaud-slate font-semibold text-xs group-hover:text-[#0F4C3A] transition-colors">
                                                {lecturer.expertise}
                                            </p>
                                        </div>
                                    </article>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* 7. GALERI DOKUMENTASI (Warm Ivory Grid with Card Hover Lift) */}
                <section id="galeri" data-section="gallery" className="bg-[#FAF6EC] border-b border-[#E3DAC7] py-12 sm:py-16 md:py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className={`flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8 pb-3 border-b border-[#E3DAC7] ${inView.gallery ? 'animate-slide-left' : ''}`}>
                            <div>
                                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-piaud-slate">
                                    Galeri Praktikum &amp; Observasi Lapangan
                                </h2>
                            </div>
                            <Link
                                href="/galeri"
                                className="group inline-flex items-center gap-1.5 text-xs font-bold text-[#0F4C3A] hover:text-[#0A3427] transition-colors self-start md:self-auto cursor-pointer"
                            >
                                <span>Buka Galeri Lengkap</span>
                                <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">&rarr;</span>
                            </Link>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            {displayedGalleries.map((item, index) => (
                                <div
                                    key={index}
                                    className={`h-full ${inView.gallery ? `animate-slide-up delay-${index + 1}` : ''}`}
                                >
                                    <figure className="neu-card card-interactive rounded-2xl p-3.5 group overflow-hidden h-full flex flex-col justify-between">
                                        <div className="overflow-hidden rounded-xl border border-[#E3DAC7]">
                                            <Photo
                                                src={item.photoUrl}
                                                alt={item.title}
                                                aspectRatio="4/3"
                                                className="w-full h-auto rounded-xl shadow-soft"
                                            />
                                        </div>
                                        <figcaption className="mt-2.5 px-1 space-y-1">
                                            <span className="text-[11px] font-bold uppercase tracking-wider text-[#C2613A] block transform group-hover:translate-x-1.5 transition-transform duration-200">
                                                {item.category}
                                            </span>
                                            <h3 className="font-serif font-bold text-sm text-piaud-slate line-clamp-2 leading-snug group-hover:text-[#0F4C3A] transition-colors">
                                                {item.title}
                                            </h3>
                                        </figcaption>
                                    </figure>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* 8. ARTIKEL PARENTING ISLAMI (Warm Cream Alternating Section with Card Hover Lift) */}
                <section id="artikel" data-section="articles" className="bg-[#F2ECE0] border-b border-[#E3DAC7] py-12 sm:py-16 md:py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className={`flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8 pb-3 border-b border-[#E3DAC7] ${inView.articles ? 'animate-slide-left' : ''}`}>
                            <div>
                                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-piaud-slate">
                                    Artikel Parenting Islami &amp; Khazanah AUD
                                </h2>
                            </div>
                            <Link
                                href="/artikel"
                                className="group inline-flex items-center gap-1.5 text-xs font-bold text-[#0F4C3A] hover:text-[#0A3427] transition-colors self-start md:self-auto cursor-pointer"
                            >
                                <span>Lihat Semua Artikel</span>
                                <span className="transform group-hover:translate-x-1.5 transition-transform duration-300 ease-out">&rarr;</span>
                            </Link>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                            {/* Featured Article Card Wrapper */}
                            <div className={`lg:col-span-6 h-full ${inView.articles ? 'animate-slide-left delay-1' : ''}`}>
                                <article className="neu-card card-interactive rounded-2xl p-5 flex flex-col justify-between group h-full">
                                    <div className="space-y-3.5">
                                        <div className="overflow-hidden rounded-xl border border-[#E3DAC7]">
                                            <Photo
                                                src={featuredArticle.photoUrl}
                                                alt={featuredArticle.title}
                                                aspectRatio="16/9"
                                                className="w-full h-auto rounded-xl shadow-soft"
                                            />
                                        </div>
                                        <div className="space-y-2 px-1">
                                            <div className="flex items-center gap-2 text-xs text-piaud-slate-muted flex-wrap">
                                                <span className="bg-[#0F4C3A] text-white px-2.5 py-0.5 rounded-md font-bold text-[11px] group-hover:bg-[#0A3427] transition-colors">
                                                    {featuredArticle.category}
                                                </span>
                                                <span>{featuredArticle.publishedAt}</span>
                                                <span>&bull;</span>
                                                <span>{featuredArticle.readTime}</span>
                                            </div>
                                            <h3 className="font-serif text-lg sm:text-xl font-bold text-piaud-slate leading-snug group-hover:text-[#0F4C3A] transition-colors">
                                                {featuredArticle.title}
                                            </h3>
                                            <p className="text-xs sm:text-sm text-piaud-slate-muted leading-relaxed">
                                                {featuredArticle.excerpt}
                                            </p>
                                        </div>
                                    </div>
                                </article>
                            </div>

                            {/* List Articles Stack (3-Card Stack Flushed Bottom) */}
                            <div className="lg:col-span-6 flex flex-col justify-between gap-4 h-full">
                                {listArticles.map((article, idx) => (
                                    <div
                                        key={article.id}
                                        className={`flex-1 flex flex-col ${inView.articles ? `animate-slide-right delay-${idx + 1}` : ''}`}
                                    >
                                        <article className="neu-card card-interactive rounded-xl p-4 flex-1 flex flex-col justify-center space-y-1.5 group">
                                            <div className="flex items-center gap-2 text-xs text-piaud-slate-muted">
                                                <span className="text-[#C2613A] font-bold text-[11px] bg-[#FAF6EC] px-2.5 py-0.5 rounded-md border border-[#E3DAC7] transform group-hover:translate-x-1.5 transition-transform duration-200">
                                                    {article.category}
                                                </span>
                                                <span>&bull;</span>
                                                <span>{article.publishedAt}</span>
                                                <span>&bull;</span>
                                                <span>{article.readTime}</span>
                                            </div>
                                            <h3 className="font-serif text-sm sm:text-base font-bold text-piaud-slate leading-snug group-hover:text-[#0F4C3A] transition-colors">
                                                {article.title}
                                            </h3>
                                            <p className="text-xs text-piaud-slate-muted leading-relaxed line-clamp-2">
                                                {article.excerpt}
                                            </p>
                                        </article>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>
            </main>

            {/* Section 8: CTA Penutup & Institutional Footer */}
            <Footer />

            {/* Floating Left: WhatsApp PMB */}
            <FloatingWhatsApp />

            {/* Floating Right: Scroll Progress & Back to Top */}
            <ScrollProgress />
        </div>
    );
}
